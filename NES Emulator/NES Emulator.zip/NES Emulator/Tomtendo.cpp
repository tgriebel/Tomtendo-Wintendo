#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <Windows.h>
#include <chrono>
#include <thread>
#include <fstream>
#include <string>
#include <assert.h>
#include <map>
#include <sstream>
#include "types_common.h"
#include "6502.h"
#include "debug.h"
#include "bitmap.h"

Cpu6502 cpu;

InstructionMapTuple instructionMap[256];
DisassemblerMapTuple disassemblerMap[256];


void PrintInstructionMap( const InstructionMapTuple instructionMap[] )
{
	cout << "Instruction | Opcode | Address Mode | Cycles " << endl;

	for ( int instr = 0; instr < 256; ++instr )
	{
		if ( instructionMap[instr].mnemonic[0] )
			cout << hex << instr << " " << instructionMap[instr].mnemonic << " " << instructionMap[instr].descriptor << " " << (int)instructionMap[instr].cycles << endl;
		else
			cout << hex << instr << endl;
	}
}


bool IsIllegalOp( const byte opCode )
{
	if ( ( opCode & illegalOpFormat ) == illegalOpFormat )
		return true;

	for ( byte op = 0; op < numIllegalOps; ++op )
	{
		if ( opCode == illegalOps[op] )
			return true;
	}

	return false;
}


bool buildInstructionMap()
{
	for ( int instr = 0; instr < 256; ++instr )
	{
		instructionMap[instr].instr = Instr::NOP;
		instructionMap[instr].addrFunc = Instr::Zero;
		strcpy_s( instructionMap[instr].descriptor, "NOP/NA" );
		instructionMap[instr].cycles = 1;
		instructionMap[instr].mnemonic[0] = '\0';
	}

	for ( int instr = 0; instr < 256; ++instr )
	{
		OpCodeMap opCode;
		AddrMapTuple addrCode = { 0x00, "",	"", NULL, iNil, 0, 0 };

		bool found = false;

		if ( IsIllegalOp( instr ) )
			continue;

		for ( byte op = 0; op < numOpCodes; ++op )
		{
			if ( ( instr & opMap[op].format ) == opMap[op].byteCode )
			{
				opCode = opMap[op];

				found = ( opCode.byteCode == instr );

				if ( opMap[op].format == ADDR_OP )
				{
					for ( int addr = 0; addr < numAddrModes; ++addr )
					{
						if ( ( instr & 0x1F ) == addrMap[addr].byteCode )
						{
							addrCode = addrMap[addr];
							found = instr == ( opCode.byteCode | addrCode.byteCode );
							break;
						}
					}
				}

				if ( found )
					break;
			}
		}

		if ( !found )
			continue;

		instructionMap[instr].instr = opCode.instr;
		instructionMap[instr].addrFunc = addrCode.addrFunc;

		if ( addrCode.addrFunc )
		{
			instructionMap[instr].params.reg0 = addrCode.reg;
			instructionMap[instr].params.reg1 = opCode.reg0;
		}
		else
		{
			instructionMap[instr].params.reg0 = opCode.reg0;
			instructionMap[instr].params.reg1 = opCode.reg1;
		}

		if ( instructionMap[instr].params.reg0 == iX && instructionMap[instr].params.reg0 == instructionMap[instr].params.reg1 )
		{
			instructionMap[instr].params.reg0 = iY;
		}

		instructionMap[instr].operands = opCode.operands + addrCode.operands;
		instructionMap[instr].params.getAddr = addrCode.addrFunc;
		instructionMap[instr].params.statusFlag = opCode.bit;

		instructionMap[instr].cycles = opCode.cycles + addrCode.cycles;

		strcpy_s( instructionMap[instr].mnemonic, opCode.mnemonic );
		strcpy_s( instructionMap[instr].descriptor, addrCode.descriptor );

		strcpy_s( disassemblerMap[instr].opCode, opCode.mnemonic );
		strcpy_s( disassemblerMap[instr].addrFormat, addrCode.format );
		disassemblerMap[instr].length = opCode.operands + addrCode.operands + 1;
	}

	return true;
}


bool Load6502Program( const string fileName, const half loadAddr, const half resetVector )
{
	ifstream programFile;
	programFile.open( fileName, ios::binary );
	std::string str( ( istreambuf_iterator< char >( programFile ) ), istreambuf_iterator< char >() );
	programFile.close();

	memset( cpu.memory, 0, cpu.VirtualMemorySize );
	memcpy( cpu.memory + loadAddr, str.c_str(), str.size() );

	cpu.resetVector = resetVector;

	cpu.Reset();

	return true;
}


bool Easy6502Tests()
{
	Load6502Program( "Program1.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed1 = ( cpu.A == 0x08 ) && ( cpu.X == 0x00 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x0610 ) && ( cpu.P == 0x30 );

	Load6502Program( "Program2.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed2 = ( cpu.A == 0x84 ) && ( cpu.X == 0xC1 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x0607 ) && ( cpu.P == 0xB1 );

	Load6502Program( "Program3.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed3 = ( cpu.A == 0x00 ) && ( cpu.X == 0x03 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x060E ) && ( cpu.P == 0x33 );

	Load6502Program( "Program4.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed4 = ( cpu.A == 0x01 ) && ( cpu.X == 0x00 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x0609 ) && ( cpu.P == 0xB0 );

	Load6502Program( "Program5.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed5 = ( cpu.A == 0xCC ) && ( cpu.X == 0x00 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0xCC02 ) && ( cpu.P == 0xB0 );

	Load6502Program( "Program6.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed6 = ( cpu.A == 0x0A ) && ( cpu.X == 0x01 ) && ( cpu.Y == 0x0A ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x0612 ) && ( cpu.P == 0x30 );

	Load6502Program( "Program7.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed7 = ( cpu.A == 0x0A ) && ( cpu.X == 0x0A ) && ( cpu.Y == 0x01 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x0612 ) && ( cpu.P == 0x30 );

	Load6502Program( "Program8.bin", 0x0600, 0x0600 );
	cpu.Run();

	const byte memCheckValues[48] = {	0x0f, 0x0e, 0x0d, 0x0c, 0x0b, 0x0a, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00,
										0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
										0x0f, 0x0e, 0x0d, 0x0c, 0x0b, 0x0a, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00 };

	bool memCheck = true;

	for ( half i = 0x00; i < 0x0F; ++i )
	{
		if ( cpu.memory[0x01f0 + i] != memCheckValues[i] )
		{
			memCheck = false;
			break;
		}
	}

	const bool passed8 = memCheck && ( cpu.A == 0x00 ) && ( cpu.X == 0x10 ) && ( cpu.Y == 0x20 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x0619 ) && ( cpu.P == 0x33 );

	Load6502Program( "Program9.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed9 = ( cpu.A == 0x03 ) && ( cpu.X == 0x00 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x060C ) && ( cpu.P == 0x30 );

	Load6502Program( "Program10.bin", 0x0600, 0x0600 );
	cpu.Run();
	const bool passed10 = ( cpu.A == 0x00 ) && ( cpu.X == 0x05 ) && ( cpu.Y == 0x00 ) && ( cpu.SP == 0xFD ) && ( cpu.PC == 0x0613 ) && ( cpu.P == 0x33 );

	return passed1 && passed2 && passed3 && passed4 && passed5 && passed6 && passed7 && passed8 && passed9 && passed10;
}


bool KlausTests()
{
	Load6502Program( "6502_functional_test.bin", 0x0000, 0x0400 );

	cpu.Run();

	return ( cpu.A == 0x42 ) && ( cpu.X == 0x52 ) && ( cpu.Y == 0x4B ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x09D0 ) && ( cpu.P == 0x30 );
}


float RunTests()
{
	uint passedTests = KlausTests() ? 1 : 0;

	passedTests += Easy6502Tests() ? 1 : 0;

	return ( passedTests / 2.0f );
}


int main()
{
	cout << "Building Instruction Map" << endl;

	buildInstructionMap();

	// PrintInstructionMap( instructionMap );
	cout << "Loading Program" << endl;

	cpu.Reset();

	cout << "Executing Program" << endl;

#if NES_MODE == 1
	NesCart cart;
	LoadNesFile( "Donkey Kong.nes", cart );

	cpu.LoadProgram( cart );

	//cpu.Run();
#else
	const float passedPercent = RunTests();

	cout << "Passed Tests %" << ( passedPercent * 100.0f ) << endl;
#endif

#if DEBUG_MEM
	/*
	uint colorIndex[] = { 0x000000FF, 0xFFFFFFFF,	0x880000FF, 0xAAFFEEFF,
		0xCC44CCFF, 0x00CC55FF, 0x0000AAFF, 0xEEEE77FF,
		0xDD8855FF, 0x664400FF, 0xFF7777FF, 0x333333FF,
		0x777777FF, 0xAAFF66FF, 0x0088FFFF, 0xBBBBBBFF };
	/*
	for ( std::map< half, byte>::iterator it = memoryDebug.begin(); it != memoryDebug.end(); ++it )
	{
		const uint x = ( it->first - 0x200 ) % 32;
		const uint y = ( it->first - 0x200 ) / 32;

		image.setPixel( x, 31 - y, colorIndex[it->second % 16] );
	}
	*/

	uint colorIndex[] = { 0x000000FF, 0xFF0000FF,	0x880000FF, 0xAAFFEEFF };

	Bitmap image( 128, 256, 0x00 );
	
	int tileIx = 0;

	const byte tilebytes = 16;

	for ( int tileIx = 0; tileIx < 512; ++tileIx )
	{
		const half baseAddr = cart.header.prgRomBanks * 0x4000;
		
		const half chrRomBase = baseAddr + tileIx * tilebytes;

		for ( int y = 0; y < 8; ++y )
		{
			for ( int x = 0; x < 8; ++x )
			{
				const byte chrRom0 = cart.rom[chrRomBase + y];
				const byte chrRom1 = cart.rom[chrRomBase + ( tilebytes / 2 ) + y];

				const half xBitMask = ( 0x80 >> x );

				const byte lowerBits = ( ( chrRom0 & xBitMask ) >> ( 7 - x ) ) | ( ( ( chrRom1 & xBitMask ) >> ( 7 - x ) ) << 1 );

				const uint imageX = x + ( tileIx % 16 ) * 8;
				const uint imageY = y + 8 * floor( tileIx / 16.0f );

				image.setPixel( imageX, 255 - imageY, colorIndex[lowerBits] );
			}
		}

		//stringstream bitmapNameStream;
		//bitmapNameStream << "output" << tileIx << ".bmp";
		//image.write( bitmapNameStream.str() );
	}
	

	image.write( "output.bmp" );
	
#endif // #if DEBUG_MEM

	return 0;
}

