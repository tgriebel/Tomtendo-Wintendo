#include "stdafx.h"

namespace Mapper
{
	void NROM()
	{
		
	}

	void MMC1()
	{
	
	}
}