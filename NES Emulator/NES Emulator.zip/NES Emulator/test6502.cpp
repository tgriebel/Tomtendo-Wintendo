#include "6502.h"
#include "stdafx.h"


bool passKlausTests()
{

	return false;

	//return ( cpu.A == 0x42 ) && ( cpu.X == 0x52 ) & ( cpu.Y == 0x4B ) && ( cpu.SP == 0xFF ) && ( cpu.PC == 0x09D0 ) && ( cpu.P == 0x30 );
}