#include "stdafx.h"
#include <assert.h>
#include "types_common.h"
#include "6502.h"

class NesSystem
{
	static const half PhysicalMemorySize = 0x0800;
	static const half VirtualMemorySize = 0xFFFF;

	Cpu6502Config config;

	byte memory[VirtualMemorySize];

	PPU ppu;
	Cpu6502 cpu;

	void LoadProgram( const NesCart& cart )
	{
		memset( memory, 0, VirtualMemorySize );

		memcpy( memory + config.Bank0, cart.rom, config.BankSize );

		assert( cart.header.prgRomBanks <= 2 );

		if ( cart.header.prgRomBanks == 1 )
		{
			memcpy( memory + config.Bank1, cart.rom, config.BankSize );
		}
		else
		{
			memcpy( memory + config.Bank1, cart.rom + config.Bank1, config.BankSize );
		}

		cpu.resetVector = ( memory[config.ResetVectorAddr + 1] << 8 ) | memory[config.ResetVectorAddr];

		cpu.Reset();
	}
};