#include "6502.h"
#include "stdafx.h"


bool passKlausTests()
{

	return false;

	//return ( A == 0x42 ) && ( X == 0x52 ) & ( Y == 0x4B ) && ( SP == 0xFF ) && ( PC == 0x09D0 ) && ( P == 0x30 );
}